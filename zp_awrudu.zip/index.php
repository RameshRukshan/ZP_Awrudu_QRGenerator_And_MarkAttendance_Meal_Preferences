<?php include_once('inc/header.php');  ?>
<?php include_once('pages/all_users.php'); ?>
<?php include_once('inc/footer.php');  ?>