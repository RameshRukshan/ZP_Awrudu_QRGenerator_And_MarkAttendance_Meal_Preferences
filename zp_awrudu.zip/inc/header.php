<!DOCTYPE html>
<html>
<head>
	<title>ZP Awrudu</title>
	<!-- Latest compiled and minified CSS -->
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

 <style>
  body{
    display: flex; 
	margin: 0; 
	padding: 0; 
	height: 100vh; 

	background: #8c3a14; 
  
  }

  #mycontainer{
    display: flex;  
	margin: 0; 
	padding: 0; 
	height: 100vh; 
	

	background: #8c3a14; 
  }
  #myform{
    background-color: rgba(0,0,0,0.7);
    margin-top: 50px;
    padding: 15px;
  }
  label{
    color: white;
  }

  </style>
</head>
<body>
  
     